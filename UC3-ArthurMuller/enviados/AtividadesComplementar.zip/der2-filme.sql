CREATE TABLE director (
	idDirector INT PRIMARY KEY AUTO_INCREMENT,
    name_director VARCHAR(40) NOT NULL,
    gender_director CHAR NOT NULL,
    place_birth_director VARCHAR(20),
    country_director VARCHAR(20),
    year_birth_director INT NOT NULL
);

CREATE TABLE studio (
	idStudio INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(40) NOT NULL,
    city VARCHAR (20),
    frounded INT NOT NULL,
    company_type VARCHAR(40) NOT NULL
);

CREATE TABLE actor (
	idActor INT PRIMARY KEY AUTO_INCREMENT,
    name_actor VARCHAR(40) NOT NULL,
    education VARCHAR(15) NOT NULL,
    gender_actor VARCHAR(6) NOT NULL,
    nationality VARCHAR(20) NOT NULL,
    year_of_birth INT NOT NULL
);

CREATE TABLE movie (
	idMovie INT PRIMARY KEY AUTO_INCREMENT,
    director_idDirector INT,
    studio_idStudio INT,
    name_movie VARCHAR(40) NOT NULL,
    country_of_realese VARCHAR(20) NOT NULL,
    languagee VARCHAR(15) NOT NULL,
    year_of_release INT NOT NULL,
    category VARCHAR(20) NOT NULL,
    FOREIGN KEY (director_idDirector) REFERENCES director(idDirector),
    FOREIGN KEY (studio_idStudio) REFERENCES studio(idStudio)
);

CREATE TABLE lacamento (
	idCasts INT PRIMARY KEY AUTO_INCREMENT,
    idMovie INT,
    idActor INT,
    roletype VARCHAR(20),
	FOREIGN KEY (idMovie) REFERENCES movie(idMovie),
    FOREIGN KEY (idActor) REFERENCES actor(idActor)
);
			