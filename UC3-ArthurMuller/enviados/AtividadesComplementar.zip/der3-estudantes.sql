CREATE TABLE student(
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_student VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE instructor (
	id INT PRIMARY KEY AUTO_INCREMENT,
    name_instructor VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE department (
	id INT PRIMARY KEY AUTO_INCREMENT,
	name_departament VARCHAR(100) NOT NULL,
    code_departament VARCHAR(50) NOT NULL
);


CREATE TABLE course (
	id INT PRIMARY KEY AUTO_INCREMENT,
    code_course VARCHAR(50) NOT NULL,
    descricpition VARCHAR(100) NOT NULL,
    idStudent INT,
    idInstructor INT,
    idDepartment INT,
    FOREIGN KEY (idStudent) REFERENCES student(id),
    FOREIGN KEY (idInstructor) REFERENCES instructor(id),
    FOREIGN KEY (idDepartment) REFERENCES department(id)
);