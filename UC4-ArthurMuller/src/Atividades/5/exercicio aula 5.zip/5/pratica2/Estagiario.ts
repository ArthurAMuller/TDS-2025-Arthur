import { Funcionario } from "./Funcionario"; export class Estagiario extends Funcionario{
    receberAjudaDeCusto(){
        let Ajuda = this.salario+100;
        console.log(`Salario de Estragiario é  R$ ${Ajuda}+ 100 R$ de Ajuda`);
    }
}