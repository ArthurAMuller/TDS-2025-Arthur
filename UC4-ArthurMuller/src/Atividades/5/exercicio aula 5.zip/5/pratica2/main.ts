import { Gerente } from "./Gerente";
import { Estagiario } from "./Estagiario";

const gerentes = new Gerente("joseph joestar",3400);
const estagiario = new Estagiario("Jotaro Kujo", 1300);

gerentes.aumentarSalario();
gerentes.aumentarSalario();
estagiario.receberAjudaDeCusto();
gerentes.aumentarSalario();