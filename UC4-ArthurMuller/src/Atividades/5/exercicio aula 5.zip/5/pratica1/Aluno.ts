import { Persona } from "./Persona"; export class Aluno extends Persona {
    estudar(){
        console.log(`Estou estudando um monte e não entendo bulhufaz!!!`)
    }
}