import { Moto } from "./Moto";
import { Carro } from "./Carro";

const car = new Carro ("Xiaomi", "SU7", 10)
const bike = new Moto("harley davidson", "FatBoy", 40)

car.acelerar()
car.acelerar()
car.acelerar()
car.freiar()
car.freiar()
car.freiar()
console.log(`------------------------`)
bike.acelerar()
bike.acelerar()
bike.acelerar()
bike.freiar()
bike.freiar()
bike.freiar()