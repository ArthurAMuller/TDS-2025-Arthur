import { Animal } from "./Animal";

export class Gato extends Animal {
    falar(): void {
        console.log(`Miau Maiu!`)
    }
}