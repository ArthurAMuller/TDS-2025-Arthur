export interface Instrumento{
    tocar(): void
}