import { Animal } from "./animal";

export class Passaro extends Animal {
    falar(): void {
        console.log("Caw, Caw")
    }   
}