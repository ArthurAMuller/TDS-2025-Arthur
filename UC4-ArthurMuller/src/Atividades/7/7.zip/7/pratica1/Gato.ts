import { Animal } from "./animal";

export class Gato extends Animal{
    falar(): void {
        console.log("Miau, Meow")
    }
}