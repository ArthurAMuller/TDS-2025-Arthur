import { Animal } from "./animal";

export class Cachorro extends Animal {
    falar(): void {
        console.log("Au Au")
    }
}