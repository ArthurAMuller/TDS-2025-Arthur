export class Animal{
    falar(): void{
        console.log("O animal emitiu som")
    }
}